/**
 * 
 */
/**
 * @author muska
 *
 */
module mod1 {
	
	exports com.cgi.pack1;
	requires sampletestmodule;
}