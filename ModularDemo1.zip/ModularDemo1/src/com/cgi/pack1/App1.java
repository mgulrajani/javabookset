package com.cgi.pack1;

import com.cgi.apps.CalculatorTester;

public class App1 {
public static void main(String[] args) {
	CalculatorTester ct =  new CalculatorTester();
	System.out.println(ct.toString());
}
}
