package com.cgi.pack2;

import java.time.LocalDate;

import com.cgi.pack1.Emp;

public class Appraisal {
    private Emp e;
    
	private LocalDate appraisalDate;

	public Emp getE() {
		return e;
	}

	public void setE(Emp e) {
		this.e = e;
	}

	public LocalDate getAppraisalDate() {
		return appraisalDate;
	}

	public void setAppraisalDate(LocalDate appraisalDate) {
		this.appraisalDate = appraisalDate;
	}

	@Override
	public String toString() {
		return "Appraisal [e=" + e + ", appraisalDate=" + appraisalDate + "]";
	}

	public Appraisal(Emp e, LocalDate appraisalDate) {
		super();
		this.e = e;
		this.appraisalDate = appraisalDate;
	}
	
	
	
}
