
package com.test.threads;

import java.util.logging.Level;
import java.util.logging.Logger;


public class PrintingTable {
    private int num;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
   
    public PrintingTable(int a) {
        this.num = a;
    }
    public void printTable()
    {String nm =Thread.currentThread().getName();
    for (int i=1;i < 11;i++)
    {
        
        System.out.println(nm + num + "*" + i +"=" + num*i);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            System.out.println("interrupted ...");
        }
    }
    
    }
    
    
}
