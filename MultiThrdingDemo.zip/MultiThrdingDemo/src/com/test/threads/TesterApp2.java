
package com.test.threads;
public class TesterApp2 {
    public static void main(String[] args) {
        Counter counter1 =  new Counter(5);
        
        Counter counter2 =  new Counter(10);
        Counter counter3=  new Counter(15);
        Counter counter4 =  new Counter(20);
        
        Thread t1 = new Thread(counter1);
        t1.setName("Counter 1");
        t1.start();
        
        Thread t2= new Thread(counter2);
        t2.setName("Counter 2");
        t2.start();
        Thread t3 = new Thread(counter3);
        t3.setName("Counter 3");
        t3.start();
        Thread t4 = new Thread(counter4);
        t4.setName("Counter 4");
        t4.start();
        
        
    }
  



}
