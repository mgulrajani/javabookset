
package com.test.threads;

public class Racer extends Thread{
    
    public void run()
    {for(int i=0;i<4;i++)
    {
        System.out.println("Hello from "
                +currentThread().getName()+ i +"times");
    try
    {
         Thread.sleep(2000);
    }
    catch(InterruptedException ie)
    {
        System.out.println("interrupted .... ");}
    }
    
    }
    
    
}
