/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.threads;

/**
 *
 * @author muska
 */
public class TesterApp {
  static  Racer racer1 =  new Racer();
   
    public static void main(String[] args) {
      racer1.setName("Racer 1");
      
        racer1.start();
       
       
        System.out.println("starting thread ...");
        Racer racer2 =  new Racer();
        racer2.setName("Racer 2");
        try
        {
            //racer1.join();
        Thread.sleep(1000);
        racer2.start();
        }
        catch(InterruptedException ie)
        {
            System.out.println("interrupted ...");
        }
    }
    
    
    
}
