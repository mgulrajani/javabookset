
package com.test.threads;

public class Counter implements Runnable {
PrintingTable pt;

Counter(int a)
{ 
    pt =  new PrintingTable(a);

}
    @Override
    public void run() {
        try
        {
            
       pt.printTable();
       Thread.sleep(1000);
        }
        catch(InterruptedException ie)
        {ie.printStackTrace();}
    }
    
    
}
