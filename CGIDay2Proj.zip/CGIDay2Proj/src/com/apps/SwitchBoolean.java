package com.apps;

public class SwitchBoolean {
public static void main(String[] args) {
	Boolean eligible = new Boolean("true");
	switch (eligible.toString())
	{
	case "true":
		System.out.println("eligible to vote");
	    break;
	case "false":
		System.out.println("not eligible to vote");
		break;
		
	}
}
}
