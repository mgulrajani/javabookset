package com.apps;

public class StringDemo {
public static void main(String[] args) {
	
	String str1 =  "hello";
	String str2 ="hello";
	
	System.out.println(str1.hashCode());
	System.out.println(str2.hashCode());
	//comparing references
	if(str1 == str2)
	{
		System.out.println("equal");
	}
	
	else
	{
		
		System.out.println("unequal");
	}
	
	//comparing the contents
	
	if(str1.equals(str2))
	{
		System.out.println("equal");
	}
	
	else
	{
		
		System.out.println("unequal");
	}
}
}
