package com.cgi.util;

import java.time.LocalDate;

import com.cgi.services.Bindable;
import com.cgi.services.Printable;

public class Book implements Printable,Bindable{
//instance variable
	
	protected int bookId;
	protected String title;
	protected Author author;
	//persistence -- writing on to localfile /rdbms 
	
	//transient will ensure that this field will
	//not get persisted 
	 protected LocalDate dateofrelease;
	
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setDateofrelease(LocalDate dateofrelease) {
		this.dateofrelease = dateofrelease;
	}
	public int getBookId() {
		return bookId;
	}
	public String getTitle() {
		return title;
	}
	
	public LocalDate getDateofrelease() {
		return dateofrelease;
	}
	public Book(int bookId, String title,
			Author author, LocalDate dateofrelease) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.dateofrelease = dateofrelease;
	}
	
	public Book()
	{
		
		super();
		
	}
	public Book(Book b1) {
		this.bookId = b1.bookId;
		this.title = b1.title;
		this.author = b1.author;
		this.dateofrelease = b1.dateofrelease;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + ", dateofrelease=" + dateofrelease
				+ "]";
	}
	
	
	//eclipse to generate source code for getters and seetters
	
	
	//eclipse to generate constructors
	
	
	public void readBook()
	{
		System.out.println("reading paperback");
	}
	@Override
	public void print() {
		System.out.println("printing a paper back book");
		
	}
	@Override
	public void bind() {
		System.out.println("books needs binding..");
	}
	
	public int hashCode()
	{
		
		int hash =  23;
		 hash+=title.hashCode();
		hash += author.getFirstName().hashCode();
		
		return hash;
		
		
		
	}	
	// if book1.equals(book2)
	public boolean equals(Object o)
	{
		Book tempbook=(Book)o;
		
		if ((this.getBookId() ==  tempbook.getBookId())
			&&
			(this.getTitle().equals(tempbook.getTitle())))
		  
		   
		   
		   return true;
		else
			return false;
		
	}
	
}
