package com.cgi.util;

public class ReaderBook  extends Book{
private String readerName;
public void readBook()
{
System.out.println("Reader is David Attenbourough");	
}
}
