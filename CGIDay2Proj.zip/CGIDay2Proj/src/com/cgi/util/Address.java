package com.cgi.util;

public class Address {

	private String bldgname;
	private String streetname;
	private String pincode;
	public String getBldgname() {
		return bldgname;
	}
	public void setBldgname(String bldgname) {
		this.bldgname = bldgname;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	
	public Address(String bldgname, String streetname, String pincode) {
		super();
		this.bldgname = bldgname;
		this.streetname = streetname;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	@Override
	public String toString() {
		return "Address [bldgname=" + bldgname + ", streetname=" + streetname + ", pincode=" + pincode + "]";
	}
	
	
}
