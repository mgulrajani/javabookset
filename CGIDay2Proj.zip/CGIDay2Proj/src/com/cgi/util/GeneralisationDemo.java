package com.cgi.util;


abstract class Animal
{

public void eat()
{System.out.println("animal eats ..");}

public void sleep()
{
System.out.println("animal sleeps ...");	
}
}

abstract class Carnivores extends Animal
{
	
public abstract void prey();

}

class Lion extends Carnivores
{

	@Override
	public void prey() {
		System.out.println("in  a group ..");
	}
	



}

class Fox extends Carnivores
{
     private boolean canine ;
     
     
	public boolean isCanine() {
		return canine;
	}


	public void setCanine(boolean canine) {
		this.canine = canine;
	}


	@Override
	public void prey() {
		System.out.println("it is really wicked ..");
	}
	

}

public class GeneralisationDemo {
 
	public static void main(String[] args) {
    Fox fox =  new Fox();
    fox.eat();
    fox.prey();
    fox.setCanine(true);
    
    
    Carnivores lion = new Lion();
   
    lion.eat();
    lion.prey();
    lion.sleep();
    
    Lion l= new Lion();
    Carnivores c =  l;
    c.eat();
    c.prey();
		
	}
             
        
        
}
