package com.cgi.util;

import java.time.LocalDate;

public class DigitalBook extends Book{

	
	private int sizeInMB;

	
	public DigitalBook(Book b1,int size)
	{
		super(b1);
		this.sizeInMB =  size;
		
		
		
	}
public DigitalBook(int bookId, String title, Author author, LocalDate dateofrelease, int sizeInMB) {
		super(bookId, title, author, dateofrelease);
		this.sizeInMB = sizeInMB;
	}

public int getSizeInMB() {
	return sizeInMB;
}

public void setSizeInMB(int sizeInMB) {
	this.sizeInMB = sizeInMB;
}

@Override
public String toString() {
	return  super.toString() +"\nDigitalBook [sizeInMB=" + sizeInMB + "]";
}
public void readBook()
{
System.out.println("reading digital book");	
}
}
