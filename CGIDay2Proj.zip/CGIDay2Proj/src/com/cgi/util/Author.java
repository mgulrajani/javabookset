package com.cgi.util;

public class Author {

	
	private int AuthorId;
	private String firstName;
	private String lastName;
	
	
	
	
	@Override
	public String toString() {
		return "Author [AuthorId=" + AuthorId + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}
	public Author() {
		super();
	}
	public Author(int authorId, String firstName, String lastName) {
		super();
		AuthorId = authorId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getAuthorId() {
		return AuthorId;
	}
	public void setAuthorId(int authorId) {
		AuthorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
