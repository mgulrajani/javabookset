package com.cgi.util;

import com.cgi.services.Printable;



public class House implements Printable {
   //class variable --static
	
	private static int ctr=0;
	//instance variables
	private int houseId;
	private int numOfRooms;
	
	//House has a Address
	private Address address;
	
	
	
	//set the houseId
	
	
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void setHouseId(int id)
	{
		
		this.houseId = id;
		
		
	}
	
	public int getHouseId()
	{return this.houseId;}
	
	public void setNumOfRooms(int num)
	{
		
		this.numOfRooms = num;
	}
	
	public int getNumOfRooms()
	{
		return this.numOfRooms;
		
	}
	
	//accessors and mutators
	//constructors
	//setters and getters
	
	
	public void startAppliances() {
	
		System.out.println("app start");	
	}
	public void stopAppliances()
	{
		System.out.println("appliances off..");
	}

	@Override
	public String toString() {
		return "House [houseId=" + houseId + ", numOfRooms=" + numOfRooms + ", address=" + address + "]";
	}

	@Override
	public void print() {
		System.out.println("house is printable");
	
		
	}
	
	
	
	
}
