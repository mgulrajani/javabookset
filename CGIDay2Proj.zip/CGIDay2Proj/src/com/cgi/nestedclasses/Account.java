package com.cgi.nestedclasses;

import java.math.BigDecimal;
import java.util.Scanner;

public class Account {
	
private  String id;
private  BigDecimal balance;

public Account(String id, BigDecimal balance) {
	super();
	this.id = id;
	this.balance = balance;
}

 class CheckSecurity
{
	void checkingSecurity()
	{
		Scanner scanner =  new Scanner(System.in);
		System.out.println("enter your password");
		String password  = scanner.nextLine();
		if(password.equals(id))
		{
			System.out.println("balance is"+balance);
		}
			
		
	}

}

public static void main(String[] args) {
	
	Account a1 =  new Account("12345678",new BigDecimal("4343434.55"));
	Account.CheckSecurity cs =  a1.new CheckSecurity();
	cs.checkingSecurity();

	
	
	new Account("345678",new BigDecimal("43434"));
	
}
}
