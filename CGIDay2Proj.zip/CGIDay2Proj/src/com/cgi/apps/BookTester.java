package com.cgi.apps;

import java.time.LocalDate;

import com.cgi.services.Printable;
import com.cgi.util.Author;
import com.cgi.util.Book;
import com.cgi.util.DigitalBook;
import com.cgi.util.House;
import com.cgi.util.ReaderBook;

public class BookTester {
	
	public static void readBook(Book b)
	{
		if(b instanceof DigitalBook)
			{b.readBook();}
		else
			if(b instanceof ReaderBook)
			{	b.readBook();}
			else if (b instanceof Book)
			{b.readBook();}
			else
				
				System.out.println("some other format of reading");
		    
	}
public static void main(String[] args) {

	 Author author1 =  new Author(11, "Dann", "Brown");
	 
	 Author author2  = new Author(12,"Simon","Singh");
	 
	 Author author3 = new Author(13,
			 "Fritzof", "Capra");
	 
	 
	 Book book1 =  new Book(1,"Tao of physics",
			 author3,LocalDate.of(2000, 10, 1));
	 
	 Book book2 =  new Book(2,"The Lost Symbol",
			 author1,LocalDate.of(1999, 11, 22));
	 
	 Book book3=  new Book(1,"Tao of physics",
			 author3,LocalDate.of(2000, 10, 1));
	 
	 Book book4 =  new Book(2,"The Lost Symbol",
			 author1,LocalDate.of(1999, 11, 22));
	 System.out.println(book1);
	 System.out.println(book2);
	DigitalBook dbook1 = new 
			DigitalBook(book1,44);
	System.out.println(dbook1);
	
	readBook(book2);
	readBook(book1);
	readBook(dbook1);
	
	Printable p1=  new Book();
	p1.print();
	Printable p2 = new House();
	
	p2.print();
	printThings(p2);
	printThings(p1);
	
	
	System.out.println("checking out the equality of the books");
	
	if(book1.equals(book3))
	{
		System.out.println("similar book");
		
	}
	else
		
		System.out.println("dissimilar");
	
	
}

public static void printThings(Object o)
{
if (o instanceof Book)
{System.out.println("book is getting printed..");
}
else if (o instanceof House)
{
System.out.println("house is getting printed");	}
else
	System.out.println("any other object ");
}

}

