package com.cgi.apps;

public class VarArgs {
	
	/*public static int add(int a,int b) {
		System.out.println("picked two args");
		return a+b;}
	*/
	public static int add(int a,int b,int c) 
	{System.out.println("picked the one with 3 args");
		return a+b+c;}
	
	public static int add(int ...a)
	{System.out.println("executing with varargs");
		int sum=0;
		for(int i:a)
		{
			sum+=i;
			
		}
		return sum;
		
		
	}
public static void main(String[] args) {
int result = 0;	
	result = add(8,9);
	System.out.println(result);
	result = add(9,9,9);
	System.out.println(result);
	result = add(4,5,6,7,8);
	System.out.println(result);
	result =  add(45,67,78,7,45,4534,343);
	System.out.println(result);
}
}
