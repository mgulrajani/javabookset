package com.cgi.apps;

import com.cgi.util.Address;
import com.cgi.util.House;

public class HouseTester {
public static void main(String[] args) {
	
	Address address1 = new Address("Galaxy","MGM Road"
			,"400001");
	
	Address address2 = new Address("The Address",
			"LBS Marg","500990");
	House house1  =  new House();
	House house2 =  new House();
	
	house1.setHouseId(111);
	house1.setNumOfRooms(3);
	house1.setAddress(address1);
	
	house2.setHouseId(114);
	house2.setNumOfRooms(4);
	house2.setAddress(address2);
	
	System.out.println(house1.getHouseId() + " "+
			house1.getNumOfRooms() + ""+
			house1.getAddress());

	
	house1.startAppliances();
	
	
	System.out.println(house2.getHouseId() + " "+
			house2.getNumOfRooms() + ""+
			house2.getAddress());
	
	house2.startAppliances();
	
}
}
