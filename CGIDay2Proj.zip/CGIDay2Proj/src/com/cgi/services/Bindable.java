package com.cgi.services;

public interface Bindable extends Printable {
public void bind();

}
