package com.cgi.services;

public interface Printable {
public void print();


default void method() {
	System.out.println("this is a def method ");
}
static void method2()
{
System.out.println("static method");	
}
}
