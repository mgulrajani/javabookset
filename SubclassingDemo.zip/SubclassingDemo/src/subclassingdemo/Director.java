
package subclassingdemo;
public class Director extends Manager{

private double budget;

    public Director(Manager m,double bud) {
        super(m);
        this.budget  =bud;
    }


    
}
