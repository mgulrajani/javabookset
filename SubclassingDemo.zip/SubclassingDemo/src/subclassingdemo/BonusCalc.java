package subclassingdemo;

import java.time.LocalDate;
import java.time.Month;

public class BonusCalc {
   
    public static float getBonus(Employee e)
    {
    
   if(e instanceof Director)
    {return .4f;}
   else if(e instanceof Manager)
        return .3f;
    else
       return .2f;
    }
    
    public static void main(String[] args) {
        
        Address add1 = new Address("Shree Complex","MG","Navi Mumba","4545454");
        Pet p1 =  new Pet("Cat","russian","brown");
        Employee e =  new Manager(LocalDate.of(2000, Month.DECEMBER, 1),112,"kevin","34343242",434244,add1,p1,"IT");
        Employee e3 =  new Employee();
        Employee e2 = new Director((Manager) e,400000);
        float retval = getBonus(e);
        System.out.println("bonus to be given is" +retval);
        retval = getBonus(e2);
        System.out.println(retval);
        retval =  getBonus(e3);
        System.out.println(retval);
        
    }
    
    
}
