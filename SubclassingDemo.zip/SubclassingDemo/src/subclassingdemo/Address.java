package subclassingdemo;
public class Address {

String bldgname;
String streetname;
String city;
String pincode;

    public String getBldgname() {
        return bldgname;
    }

    public void setBldgname(String bldgname) {
        this.bldgname = bldgname;
    }

    public String getStreetname() {
        return streetname;
    }

    public void setStreetname(String streetname) {
        this.streetname = streetname;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    @Override
    public String toString() {
        return "Address{" + "bldgname=" + bldgname + ", streetname=" + streetname + ", city=" + city + ", pincode=" + pincode + '}';
    }

    public Address() {
    }

    public Address(String bldgname, String streetname, String city, String pincode) {
        this.bldgname = bldgname;
        this.streetname = streetname;
        this.city = city;
        this.pincode = pincode;
    }

    
}
