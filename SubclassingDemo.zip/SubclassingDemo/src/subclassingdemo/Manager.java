package subclassingdemo;

import java.time.LocalDate;
import java.time.Month;

class Employee
{
protected int id;
protected String name;
protected String ssn;
protected double salary;
protected Address address;
protected Pet pet;
protected LocalDate doj;
    public Employee() {
    }
    public Employee(Employee e)
    {this.id = e.getId();
    this.name = e.getName();
    this.doj = e.doj;
    this.address = e.address;
    this.pet =e.pet;
    this.ssn = e.ssn;}
    public Employee(LocalDate date1,int id, String name, String ssn, double salary,Address add,Pet p1) {
        this.id = id;
        this.name = name;
        this.ssn = ssn;
        this.salary = salary;
        this.address =  add;
        this.pet = p1;
        this.doj  =date1;
    }

    @Override
    public String toString() {
        return "Employee{" + "id=" +doj+ id + ", name=" + name + ", ssn=" + ssn + ", salary=" + salary +address+ pet+'}';
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }



}

public class Manager extends Employee{
    private String deptname;
    
    Manager(Manager m)
    {
    this.id = m.id;
    this.name = m.name;
    this.address = m.address;
    this.doj =  m.doj;
    this.pet = m.pet;
    this.ssn = m.ssn;
    this.salary = m.salary;
    
    
    
    }
    Manager(Employee e,String deptnm)
    {
    super(e);
    this.deptname = deptnm;
    
    }
    Manager()
    {
    super();
    this.deptname = "admin";
    
    }
    Manager(LocalDate d1,int id,String nam,String ssn,double sal,Address ad,Pet p1,String dn)
    {
    super(d1,id,nam,ssn,sal,ad,p1);
    this.deptname = dn;
    
    }
    public String toString()
    {
    
    return super.toString() + this.deptname;
    }
    
    
    public static void main(String[] args) {
       
        LocalDate date1 =  LocalDate.of(2012,Month.DECEMBER, 12);
        Address add1=  new Address("akshar","mg","navi mumbai","34343");
        Employee e1=  new Manager();
        Manager m1  = new Manager(date1,121,"john","324324",234234,add1,new Pet("dog","german shepherd","black"),"sales");
        
        System.out.println("Details of the employee are as follows "+m1);
        
        System.out.println(e1);
       
        
    }
    
    
    
    
    
    
    
    
    
    
    
}
