
package com.test.threads;
public class Data {

public String message;
Data(String data)
{this.message = data;}
    @Override
    public String toString() {
        return "Data{" + "message=" + message + '}';
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    
}
