/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.threads;



public class Tester3{
public static void main(String[] args) {
	

	Data msg = new Data("process it");
	Data msg2 = new Data("java multithreading...");
    Sender sender1 = new Sender(msg2);
    
        
    Sender sender2 = new Sender(msg);
    new Thread(sender2, "sender2").start();
    
    Receiver receiver = new Receiver(msg);
    receiver.start();
    sender2.start();
    
    new Thread(receiver, "receiver").start();
    System.out.println("All the threads are started");
}
}
