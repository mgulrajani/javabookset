
package com.test.threads;

public class Sender extends Thread {
    Data data;
    Sender(Data d1)
    {this.data = d1;}
    public void run()
    {
    String nm =Thread.currentThread().getName();
        synchronized(data)
        {
            System.out.println(nm + "Thread started ....");
        data.setMessage("how are you");
                System.out.println("message is set and sent ...");
                try
                {
                    Thread.sleep(2000);
                    
                
                
                }
                catch(InterruptedException ie)
                {ie.printStackTrace();}
                data.notifyAll();
                System.out.println
        ("notification sent to all the waiting threads");
        }
    
    
    
    }
            
    
    
    
}
