
package com.test.threads;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Receiver extends Thread{
    Data data;
    Receiver(Data d1)
    {this.data=d1;}
    public void run()
    {
    
    String nm =  Thread.currentThread().getName();
    synchronized(data)
    {
        try {
            System.out.println("waiting for the messages ....");
            data.wait(1000);
        } catch (InterruptedException ex) {
            System.out.println("interrupted .....");
        }
        System.out.println("Message recd" +data.getMessage());
        
                
    
    
    }
    
    
    }
}
