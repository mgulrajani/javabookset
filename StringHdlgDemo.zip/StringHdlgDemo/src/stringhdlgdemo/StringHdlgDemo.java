package stringhdlgdemo;

public class StringHdlgDemo {
    public static void main(String[] args) {
     //immutables 
     
     String str1 =  "Hello";
     String str2 = "Hello";
     String str3 = new String("Hello");
     if (str1.equals(str2))
     {
         System.out.println("checking contents");
         System.out.println("found equal");
     }
     if(str1==str2)
     {
     
         System.out.println("pointing to the same object ");
     }
      str1=  str1.concat("world");
        System.out.println(str1);

        StringBuilder sb1 = new StringBuilder();
        sb1.append("hello again");
        
        sb1.indexOf("again");
        




    }
    
}
