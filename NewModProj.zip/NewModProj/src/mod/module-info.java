module mod
{
exports pack1;
}