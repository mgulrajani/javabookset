package pack1;

public class Test1
{

public Test1()
{
System.out.println("hello");}
}