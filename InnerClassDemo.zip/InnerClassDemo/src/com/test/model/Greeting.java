
package com.test.model;
@FunctionalInterface
public interface Greeting {
public void greet(String msg);




}
