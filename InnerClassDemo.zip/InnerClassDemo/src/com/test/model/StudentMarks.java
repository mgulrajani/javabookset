package com.test.model;

import java.util.Scanner;

public class StudentMarks {
int id;
String name;
String grade;

    @Override
    public String toString() {
        return "StudentMarks{" + "id=" + id + ", name=" + name + ", grade=" + grade + '}';
    }

    public StudentMarks(int id, String name, String grade) {
        this.id = id;
        this.name = name;
        this.grade = grade;
    }
    
    public int CalculateMarks()
    {
    class Marks
    {
    int sub1;
    int sub2;
    int sub3;
    Marks(int a,int b,int c)
    {
    this.sub1 =a;this.sub2 = b;this.sub3= c;
    }
    public int calculate_total()
    {
    return sub1+sub2+sub3;
    }
    }
    Scanner scan= new Scanner(System.in);
        System.out.println("Enter  marks for 3 subjects ...");
    int a =scan.nextInt();
    int b =scan.nextInt();
    int c =scan.nextInt();
    
    Marks m1 =  new Marks(a,b,c);
    int total =  m1.calculate_total();
    return total;
       
    }
    

    public static void main(String[] args) {
        StudentMarks sm = new StudentMarks(121, "akash","x");
         int totalmarks = sm.CalculateMarks();
         System.out.println("total marks are "+totalmarks);
    
    }




}
