/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.model;

import java.util.function.Function;

/**
 *
 * @author muska
 */
public class Tester {
    
    public static void main(String[] args) {
       
        Greeting g1 =  new Greeting(){public void greet(String m)
    {
        System.out.println("hello" +m);
    
    }};
    
        String msg = "world";
        g1.greet(msg);
    
    
    
    Greeting g2 =  (String m)->{System.out.println("hello from "
            + "lambda "+m);};
    
    g2.greet("hello universe");
    
    Greeting g3 = (String m2)->{System.out.println(m2+" new value for msg");};
    
    g3.greet("hello all ");
        System.out.println("starting thread ...");
    new Thread(
            ()->{System.out.println("hello from thread ...");})
            .start();
    
        System.out.println("thread started ...");
    
    Function<String,Integer> fun1 = Integer::parseInt;
    int x =fun1.apply("23233");
        System.out.println(x);
        
    Function<String,Integer> fun2  = (String ss)->Integer.parseInt(ss);
            
    }
    
    
    
}
