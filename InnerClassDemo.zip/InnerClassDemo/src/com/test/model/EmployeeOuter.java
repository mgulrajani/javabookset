
package com.test.model;

public class EmployeeOuter {
    int id;
    String name;
    float sal;

    @Override
    public String toString() {
        return "EmployeeOuter{" + "id=" + id + ", name=" + name + ", sal=" + sal + '}';
    }

    public EmployeeOuter(int id, String name, float sal) {
        this.id = id;
        this.name = name;
        this.sal = sal;
    }
    
     class CalculateSalary
     {
     
     public float calcSal()
     {
     return sal*1.2f;
         
     }
     
     }
    public static void main(String[] args) {
        
        EmployeeOuter em1 =
                new EmployeeOuter(111, "kevin", 120000f);
        EmployeeOuter.CalculateSalary innerobj =
                em1.new CalculateSalary();
        float grosssal =innerobj.calcSal();
                System.out.println("gross sal is "+grosssal);
        
    }
    
    
}
