package com.test.model;

import java.util.logging.Level;
import java.util.logging.Logger;

public class AnnonymousDemo {

    public static void main(String[] args) {
     Thread t1 =  new Thread(new Runnable(){public void run()
     {
     
         try {
             doSomeWork();
             Thread.sleep(1000);
         } catch (InterruptedException ex) {
             System.out.println("interrupted from sleep ...");
         }
     
     }});
     t1.setName("Worker thread ...");
t1.start();

        
    }
    public static void doSomeWork()
    {String name =  Thread.currentThread().getName();
    
for(int i=0;i<5;i++){
        try {
            System.out.println("hello from"+name  + i+" times ");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            System.out.println("oops ..");
        }
    
}
    }
}
