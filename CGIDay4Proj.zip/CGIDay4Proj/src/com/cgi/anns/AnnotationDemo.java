package com.cgi.anns;
//meta data  - java code - type,method,constructor ,fiedl
//runtime, class ,source 
//dont directly affect execution
//Spring,Hibernate --make heavy use of annotation
//3 built in java annotation
//@Override



public class AnnotationDemo {

}
