package com.cgi.anns;

public class Child extends Parent{

	@Override
	public void myMethod() {
		// TODO Auto-generated method stub
		super.myMethod();
		System.out.println("child");
	}

}
