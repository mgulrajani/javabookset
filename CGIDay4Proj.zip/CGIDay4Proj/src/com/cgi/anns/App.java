package com.cgi.anns;

import java.lang.annotation.Annotation;

public class App {
public static void main(String[] args) {
	
	new Parent().myMethod();
	Class class1 = Parent.class;
	
	Annotation[] ano=class1.getAnnotations();
	
	for(Annotation  a: ano)
	{
		System.out.println(a.toString());
		
	}
	
	
}
}
