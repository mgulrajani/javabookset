package com.cgi.anns;
@Author(pubs= {"packt"})
public class Parent {
@Author(id=99,name="xx",pubs= {"abc"})
	Parent()
	{
	
	System.out.println("parent obj init");
	}
	
@Deprecated
public void myMethod()
{
	
System.out.println("parent");
}
}
