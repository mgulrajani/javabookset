package com.cgi.streams;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsJava9 {
public static void main(String[] args) {
	
	List<String> alphabets =
			List.of("a","b","c","d","e","f","g");
	List<String>  subset = 
			alphabets
			.stream()
			.takeWhile(s->!s.equals("d"))
			.collect(Collectors.toList());
	System.out.println(subset);


List<String>  subset2 = 
alphabets
.stream()
.dropWhile(s->!s.equals("d"))
.collect(Collectors.toList());
System.out.println(subset2);
//java 8
List<Integer> nums =  Stream
					.iterate(1,i->i+1)
					.limit(20)
					.collect(Collectors.toList());

System.out.println(nums);

//java 9
List<Integer> nums3 =
					Stream
					.iterate(100,i->i<=1000,i->i+100)
					.limit(20)
					.collect(Collectors.toList());
System.out.println(nums3);


Stream<String> stream =
Stream.ofNullable("1233232");
System.out.println(stream.count());
		

Stream<String> stream1 =
Stream.ofNullable(null);
System.out.println(stream1.count());
		
}}
