package com.cgi.process;

import java.util.stream.Stream;

public class ProcessDemo {
     @Deprecated(forRemoval=true,since="10")
	public void add() {}
	public static void main(String[] args) {
		   
		ProcessHandle phandle = ProcessHandle.current();
		
		System.out.println(phandle.pid());
		
		ProcessHandle.Info  info = phandle.info();
		
		System.out.println
		(info.arguments().isPresent());

		System.out.println
		(info.command().get().contains("java"));
		
		Stream<ProcessHandle> stream =phandle.descendants();
		
		stream.forEach(System.out::println);
		
Stream<ProcessHandle> stream1 =ProcessHandle.allProcesses();
		
		stream1.forEach(System.out::println);
		
	}
	
}
