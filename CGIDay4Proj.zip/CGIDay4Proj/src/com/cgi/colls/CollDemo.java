package com.cgi.colls;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CollDemo {
public static void main(String[] args) {
	//pre - java9
	
	Set <String> set1 =  new HashSet<>();
	set1.add("ketan");
	set1.add("aarav");
	set1.add("utsav");
	
	Set<String> confirmedset = 
			Collections.unmodifiableSet(set1);
	

    //immutable set /list in java9
	
	Set<String> names= Set.of("Uditi","Aditi","REne");
	
	
	System.out.println(names);
 
	
	Map<String,Integer> marks=Map.ofEntries
			(Map.entry("Ayesha", 89),
			Map.entry("Kim",78),
			Map.entry("Jack", 88));
	
	System.out.println(marks);
	
	

	

}
}
