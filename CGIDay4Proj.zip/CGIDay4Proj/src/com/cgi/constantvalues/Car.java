package com.cgi.constantvalues;

enum Model
{
ZXI(10000),VXI(8000),ZXD(8500),VXD(7500);	

private int price;
	public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
	private Model(int price)
	{
		this.price=price;
		
	}
	
	
}

public class Car {
private int id;
private String manufacturer;
private Model model;
private Color color;


public Car() {
	super();
}
public Car(int id, String manufacturer, Model model, Color color) {
	super();
	this.id = id;
	this.manufacturer = manufacturer;
	this.model = model;
	this.color = color;
}
@Override
public String toString() {
	return "Car [id=" + id + ", manufacturer=" + manufacturer + ", model=" + model + ", color=" + color + "]";
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getManufacturer() {
	return manufacturer;
}
public void setManufacturer(String manufacturer) {
	this.manufacturer = manufacturer;
}
public Model getModel() {
	return model;
}
public void setModel(Model model) {
	this.model = model;
}
public Color getColor() {
	return color;
}
public void setColor(Color color) {
	this.color = color;
}



}
