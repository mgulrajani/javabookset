package com.cgi.constantvalues;
//public interface Printable
//public class Car
//Enum --special Java type -- set of constants 
//collection of constant
//constructor ,abstract methods


public enum Color {
RED,BLACK,WHITE;

private Color()
{
System.out.println("color const initialised");	
}
}
