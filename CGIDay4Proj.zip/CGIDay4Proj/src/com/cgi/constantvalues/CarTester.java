package com.cgi.constantvalues;

public class CarTester {
public static void main(String[] args) {
	Car c1 =  new Car(12121,"VolksWagen",
			Model.ZXI,Color.BLACK);
	
	switch(c1.getColor())
	{
	case BLACK:
		System.out.println("black suits VW");
		break;
	case RED:
		System.out.println("RED is great..");
		
	   break;
	case WHITE:
		System.out.println("WHite seems to be right");
	
	
	}
	
	for(Model m:Model.values())
      System.out.println(m);	
	
}
}
