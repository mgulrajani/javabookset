package com.cgi.privatemethodinterface;

import java.util.Arrays;
import java.util.List;

public class App3 {
public static void main(String[] args) {
	//List<Integer> nums = Arrays.asList(1,2,4,5,6);
	Calc c=()->System.out.println("hello");
	System.out.println(c.addEvenNums(1,2,5,7,8,9));
	System.out.println(c.addOddNums(2,3,4,6,7,8));
	
}
}
