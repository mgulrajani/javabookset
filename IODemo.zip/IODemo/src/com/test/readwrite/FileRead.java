
package com.test.readwrite;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileRead {
    public static void main(String[] args) {
        FileReader fr = null;
        FileWriter fw = null ;
        BufferedReader br = null ;
        BufferedWriter bw = null ;
        try
        {
            String str = null;
        File file1= new File("c:\\mkg\\toberead.txt");
        File file2= new File("c:\\mkg\\copied.txt");
        
         fr=new FileReader(file1);
         fw =  new FileWriter(file2);
        
         br = new BufferedReader(fr);
         bw =  new BufferedWriter(fw);
        
        while (( str =br.readLine())!= null)
        {
            System.out.println(str);
            bw.write(str);
        }
        bw.flush();
        }
        catch(FileNotFoundException fnf)
        {
            System.out.println("file not found ...");
        }
        catch(IOException ioe)
        {
            System.out.println("some problems in reading the file");
        }
        finally
        {
        
            try {
                bw.close();
                fr.close();
                fw.close();
                br.close();
            } catch (IOException ex) {
                
            }
        
        }
    }
}
