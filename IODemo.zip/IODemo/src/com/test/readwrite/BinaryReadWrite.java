
package com.test.readwrite;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class BinaryReadWrite {
    public static void main(String[] args) {
        File file1=  new File("c:\\mkg\\sun.png");
        File file2 =  new File("c:\\mkg\\image2.png");
        
        int ch =0;
      try
          (FileInputStream fis= new FileInputStream(file1);
        BufferedInputStream bis=  new BufferedInputStream(fis);
                  
        FileOutputStream fos= new FileOutputStream(file2);
        BufferedOutputStream bos=  new BufferedOutputStream(fos);)
      {
                  
                  while (( ch =bis.read())!= -1)
                  {
                  bos.write(ch);
                  bos.flush();
                  }
                  
                }   
        
    
        catch (FileNotFoundException ex) {
            System.out.println("File not found");
                }
         catch(IOException ioe)
                 {System.out.println("IO exception ..");}
        }
    }
    
 