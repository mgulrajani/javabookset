package com.cgi.util;

public class MultiplicationTable {
   /* //Class variables
	public static int ctr;*/
	//instance variable
    private int num1;
	
    //constructor1
    public MultiplicationTable()
    {
    	
    	this.num1 = 5;
    }
    
    //constructor2
    public MultiplicationTable(int x)
    {//this refers to the current instance which is
    	// invoking the constructor
    this.num1 = x;	
    	
    }
    
    //constructor3
    public MultiplicationTable(MultiplicationTable m)
    {
    	this.num1 = m.num1;
    }
    
	public void printTable()
	{
		for(int i=1;i<=10;i++)
		{
			
			System.out.println(this.num1*i);
		}
		
	}
    
    
}
