package com.cgi.util;

public class WhileDemo {
public static void main(String[] args) {
	int x = 10;
//Array is an object , new operator	
int []arr =  new int[10];
//declared the array
int [][]arr2 = new int[3][];

int [][]arr3 = {{1,2,3},{4,5,6},{7,8,9,10}};

//initialized the array
arr2[0]= new int[]{1,2,3,4};
arr2[1] = new int[] {5,6,7};
arr2[2] = new int[] {8,9,10,11,12};

//iterate thru the array
System.out.println("displaying arr2 .......");
for(int i=0;i<arr2.length;i++)
{
	for(int j=0;j<arr2[i].length;j++)
	{
		System.out.print(arr2[i][j]);
		
	}
    System.out.println();
}




//declaring and initializing the array
String []names = {"john","alex","sanjay","ram"};

for(String name:names)
	{System.out.println(name);}



//assign values to the array
for (int i=0,j=1;i<arr.length;i++,j++)
{
	arr[i]= j*j;
}

//forloop to iterate thru the values
for(int i=0;i<arr.length;i++)
{System.out.print(arr[i]+"\t");}

for (int i : arr) {
	System.out.println(i);
}


//no call to the constructor 
//Calculator()
Calculator []calcarr =  new Calculator[3];

//memory allocation for calc objects

for(int i=0;i<calcarr.length;i++)
calcarr[i]=new Calculator();

for(Calculator c:calcarr)
	System.out.println(c);
}


}
