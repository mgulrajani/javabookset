package com.cgi.util;

public class IfElse {
public static void main(String[] args) {
	
	
	
	int x=10;
	int y=90;
	if(x>20 && y++>80)
		System.out.println("yes" +y);
	else
		System.out.println("no"+y);
	



if (x > 20)
{}
else if(x>30)
{}
else
{}
//  ? val1 : val2
int voterage = 23;
boolean eligible =  voterage>21 ?true :false;
System.out.println(eligible);

int dayNo = 5;

switch (dayNo)
{
case 1:
case 2:
case 3:
case 4:
case 5:
	System.out.println("weekday");
        break;
case 0:        
case 6: System.out.println("weekend");
        break;
 
        
default:System.out.println("Not a correct day no.");

}
}


}

