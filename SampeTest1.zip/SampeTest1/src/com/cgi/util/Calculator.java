package com.cgi.util;

public class Calculator {
int result;
	/* this is going to demonstrate diff data types */


  //primitive data types


   //boolean  , char , int short long float double byte 

//Objects  -- Reference types you create/ java language o

    //<<access-specifier>>  <<return data type>> <<method-name>(datatype param1 ,datatype para...)  
//{}


	public int add(int a, int b)
	{
		 result =  a+b;
		 //System.out.println(min);
		return result;
		
		
	}
	
	public void showResult()
	{
		
		int min = 0;
		
		System.out.println("result is "+result);
		
	}
	
	public String toString()
	{
		
		return "Calculator object created ...";
		
	}
}
