package com.cgi.util;
class Cat{}

public class Sample1 {
//every class will have state and behaviour
	// identity   -- hashCode
	//state is the state of the instance variables
	//behaviour  -- methods which will be applied on this state
	//instance variables 
	
	
	// JVM provides a non-argumentive constructor in case of absence
	
	//public default private protected 
   private    int num1;
	private   float num2;
	private  char charvar;
	private  byte b1;
	 private long longnum;
	
	//accessors and mutators
	//access the data
	//mutators will change the data
	

	//constructors have no return type
    public Sample1() {
    	
    	this.num1 = 100;
    	this.num2 =  200.00f;
    	this.b1=0b1011111;
    	this.charvar='a';
    	this.longnum=90999;
    	
    	
    }
	
	
	public void displayInfo()
	{
		System.out.print(num1 + "\t" +num2 + "\t"+ 
	longnum + "\t"+ b1 + "\t"+charvar+"\n");
		
	}
	
	
	
	
}
