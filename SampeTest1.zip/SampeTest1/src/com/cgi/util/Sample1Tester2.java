package com.cgi.util;

public class Sample1Tester2 {
public static void main(String[] args) {
	
	Sample1 s1 = new Sample1();
	s1.displayInfo();
	
	
	s1.displayInfo();
}
}
