package com.cgi.apps;

import com.cgi.util.Calculator;

public class CalculatorTester {

public static void main(String[] args) {
	//creating a reference variable 
	
	
	Calculator c1 = new Calculator() ;
	
	
	int x = 100;
	
	
	float y = 101.0f;
	 
	String str  = "Hello Java 9";
	
     System.out.println(c1);	

	
	
	
	
	
}



}
