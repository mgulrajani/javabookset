package com.cgi.apps;

import com.cgi.util.*;

public class MultiplicationTableTester {
public static void main(String[] args) {
	
MultiplicationTable  m1 =  new MultiplicationTable();
m1.printTable();

MultiplicationTable m2 =  new MultiplicationTable();
m2.printTable();
}}

