package com.cgi.apps;

import com.cgi.util.Sample1;

public class Sample1Tester {
  public void disp()
  {
	  
	  Sample1 s2 = new Sample1();
	 
  }
	public static void main(String[] args) {
		
		Sample1  sample1obj1 =  new Sample1();
		Sample1 sample1obj2 = new Sample1();
		
		
		//sample1obj is a reference variable
		//Sample1 is a class
		sample1obj1.displayInfo();
		sample1obj2.displayInfo();
	
		sample1obj1.displayInfo();
		
		
	}
	
	
	
}
