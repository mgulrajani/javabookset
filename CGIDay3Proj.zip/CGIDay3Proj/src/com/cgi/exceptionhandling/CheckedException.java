package com.cgi.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//character based - Reader and Writer
//Byte Stream  -- InputStream and OutputStream
//audio image

// stream -- flowing with data
//AutoClosable


public class CheckedException {

	public static void main(String[] args) 
			{
		int i=0;
		try(FileReader reader =new FileReader("c:\\mkg\\data.txt");
	FileWriter writer=new FileWriter("c:\\mkg\\newdata.txt");
				FileInputStream fis=new FileInputStream("c:\\mkg\\sun.png");
				FileOutputStream fos=new FileOutputStream("c:\\mkg\\newsun.jpg"))
		{
		while((i=reader.read())!=-1)
		{
			writer.write(i);
			
			
		}
		while((i=fis.read())!=-1)
		{
			fos.write(i);
			
			
		}
		System.out.println("new file created ...");
		}
		catch(FileNotFoundException fnf)
		{
			System.out.println("file not found");
			
		}
		catch(IOException ioe)
		{
			System.out.println(ioe.getMessage());
		}
		
		
	}
	
	
}
