package com.cgi.exceptionhandling;

import java.math.BigDecimal;

public class AccountTester {
public static void main(String[] args)  {
	
	Account a1 =  new Account("12121", 
			new BigDecimal(10000));
	
	try {
		

	a1.deposit(new BigDecimal(12000));
	System.out.println(a1.getBalance());
	a1.withdraw(new BigDecimal(20000));
	System.out.println(a1.getBalance());
	}
	catch(LessFundsException lf)
	{
		System.out.println(lf.getMessage());
		
	}
}

}
