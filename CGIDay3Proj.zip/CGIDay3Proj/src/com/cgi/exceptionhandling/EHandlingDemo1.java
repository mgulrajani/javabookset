package com.cgi.exceptionhandling;

import java.util.Scanner;

//unforeseen or unpredictable execution
//exception
//2 things --  declare or handle 
//if you are handle the exception try,catch,finally
//declare the exception -- throw and throws
//A
//B
//D


//Throwable is at the top-most of exception
//Exception and Error
//RuntimeException (UncheckedException) and CheckedException
public class EHandlingDemo1 {

	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int x=10;
		int y=1;
		int z=0;
		int []arr= {1,2,3,4,5};
		int num=0;
		int res = 0;
		try
		{
		String s="hello";
		System.out.println(s.length());
		
		
	 z=x/y;
		System.out.println("result is"+z);
		
		System.out.println("enter the number to be divided");
		num = scanner.nextInt();
		for (int i=0;i<=arr.length;i++)
		{
			
			res=num/arr[i];
			System.out.println(res);
		}
		}
		catch(ArithmeticException ae)
		{System.out.println("number cannot "
				+ "be divided by zero");
		z=x/1;
		System.out.println("result is"+z);
		}
		catch(ArrayIndexOutOfBoundsException ai)
		{
			
			System.out.println("array of lesser size");
			
		}
		catch(Exception e)
		{
			System.out.println("some exception");
		}
		finally
		{
		System.out.println("in the finally block ..");	
		scanner.close();
		
		}
		
		
	}
}
