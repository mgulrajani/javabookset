package com.cgi.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EmpFIle {
public static void main(String[] args) {
	Emp e1 = new Emp(1,"Joshua",23233.55f);
	
	try(
			FileOutputStream fos=
		new FileOutputStream("c:\\mkg\\empdata.txt");
		
	ObjectOutputStream oos =  new ObjectOutputStream(fos))
	{
		
		oos.writeObject(e1);
		
		System.out.println("Data written onto the file");
	}
	catch(FileNotFoundException fnf)
	{System.out.println("file not found");}
	catch(IOException ioe)
	{ioe.printStackTrace();}
	
}
}
