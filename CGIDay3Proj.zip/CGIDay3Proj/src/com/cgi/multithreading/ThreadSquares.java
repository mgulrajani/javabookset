package com.cgi.multithreading;

public class ThreadSquares extends Thread{
Squares squares;

public ThreadSquares(Squares squares) {
	super();
	this.squares = squares;
};
public void run()
{
squares.printSquare(10);	
}
}
