package com.cgi.multithreading;
//difference in multi threading and multiprocessing

//extending Thread
//implementing Runnable interface --functional interface
public class Racer extends Thread{
	
	Racer(String name)
	{
		this.setName(name);
	}
public void run()
{
	
	System.out.println
	(Thread.currentThread().getName());

for (int i=0;i<10;i+=2)
{
System.out.println(this.getName()+i);	
try {
	Thread.sleep(1000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

}

}

public static void main(String[] args) {
	System.out.println
	(Thread.currentThread().getName());
	Racer r1 =new Racer("Racer1");
	
	r1.start();
	Racer r2 =  new Racer("Racer2");
	r2.start();
	
}
}
