package com.cgi.multithreading;

public class Thread2Squares  extends Thread{

	Squares squares;

	public Thread2Squares(Squares squares) {
		super();
		this.squares = squares;
	}
	
	
	public void run()
	{
		
		squares.printSquare(15);
	}
}
