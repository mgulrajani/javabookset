package com.cgi.multithreading;

public class Squares {
synchronized void printSquare(int n)
{
	for(int i=1;i<=n;i++)
	{
		
		System.out.println(i*i + " "+Thread.currentThread().getName());
	}
	try
	{
		Thread.sleep(1000);
	}
	catch(InterruptedException ie)
	{
		System.out.println(ie.getMessage());
	}

}
}
