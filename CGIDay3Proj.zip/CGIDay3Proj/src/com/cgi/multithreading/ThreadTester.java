package com.cgi.multithreading;

public class ThreadTester {
public static void main(String[] args) {
	Squares squares=new Squares();
	
	ThreadSquares t1 =  new ThreadSquares(squares);
	Thread2Squares t2 =  new  Thread2Squares(squares);
	t1.start();
	t2.start();
	
}
}
