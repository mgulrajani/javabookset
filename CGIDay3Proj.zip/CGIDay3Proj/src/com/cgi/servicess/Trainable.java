package com.cgi.servicess;
//SAM - Single Abstract Model -
//before java 8 , java 8, abstract data types creates

@FunctionalInterface
public interface Trainable {
public void train();


}
