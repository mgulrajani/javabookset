package com.cgi.servicess;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.cgi.exceptionhandling.Emp;

public class ClientApp3 {
public static void main(String[] args) {
	
	List<Integer> listofnums =
			Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	
	Predicate<Integer> p1 =(n)->n%2==0;
	Predicate<Integer> p2 =(m)->m>5;
	
	printsAllEvens(listofnums,p1);
	System.out.println("printing nums greater than 5");
	printsAllEvens(listofnums,p2);
	
	Supplier<String> strsupp=()->{return new String();};
	
	Supplier<Emp>empsupp=()->{return new Emp();};
	
	getEmployee(empsupp);
	
	
	Trainable t1 =()->
	System.out.println("trainable resource");
	
	Trainable t2=()->System.out.println("not a trainable resource");
	getInfoOnTraining(t1);
	
	getInfoOnTraining(t2);
	
	Runnable r1 = ()->{
		for(int i=0;i<5;i++)
		System.out.println("hi");
		 
		
	};
	
	
	Runnable r2 = 
			()->System.out.println("thread running");
	Thread t4 = new Thread(r1);
	t4.start();
	
	Thread t5 = new Thread(r2);
	t5.start();
	
	Consumer<String> consumer =
			System.out::println;
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter your name");
	String name =  scanner.nextLine();
	printName(name,consumer);
	System.out.println("name printed");
			
}


private static void printsAllEvens
(List<Integer> listofnums, Predicate<Integer> p1) {
	System.out.println("displaying evens from list"+listofnums);
	for(Integer i:listofnums)
	{
		
		if(p1.test(i))
			System.out.println(i);
	}
	
}

private static void getEmployee(Supplier<Emp> empsupp) {
	Emp e = empsupp.get();
	e.setName("vishal");
	e.setSalary(100000);
	System.out.println(e);
}

private static void printName(String name, 
		Consumer<String> consumer) {
	consumer.accept(name);
	
}

public static void getInfoOnTraining(Trainable t)
{
t.train();

}
}
