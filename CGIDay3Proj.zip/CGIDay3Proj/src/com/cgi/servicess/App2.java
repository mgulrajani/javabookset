package com.cgi.servicess;

public class App2 {
public static void main(String[] args) {
	 Trainable t1 = new Trainable() {
		
		@Override
		public void train() {
			System.out.println("trainable resource");
		}
	};
	t1.train();
	
	
	
}
}
