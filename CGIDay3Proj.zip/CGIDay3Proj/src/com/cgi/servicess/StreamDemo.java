package com.cgi.servicess;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.cgi.exceptionhandling.Emp;

public class StreamDemo {
public static void main(String[] args) {
	
	Emp e1 = new Emp(1,"Joshua",45455f);
	Emp e2 = new Emp(2,"Anie",56566f);
	Emp e3 = new Emp(3,"Yakuta",23233.55f);
	Emp e4 = new Emp(4,"Ankit",65666f);
	
	List<Emp> listemps =  Arrays.asList(e1,e2,e3,e4);
	
	Predicate <Emp>p1=(mm)->mm.getSalary()>30000f;
	List<Emp> empsMore =
	listemps
	.stream()
	.filter(p1)
	.collect(Collectors.toList());
	
	System.out.println("emps getting sal more than 30000");
	System.out.println(empsMore);
	Predicate<Integer> p3=(n)->n>50;
    List<Integer> listofnums = 
    		Arrays.asList(45,23,55,34,56,2);
    Function<Integer,Integer> f1=
    		(n)->n*2;
    		
 
    		System.out.println("new list of numbers");
    listofnums
.stream()
.map(f1)
.forEach(System.out::println);
    
    
   

}
}
