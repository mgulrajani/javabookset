package com.cgi.servicess;

public class ClientApp {
public static void main(String[] args) {
	
	MyTrainable m1 =  new MyTrainable();
	m1.train();
	
}
}
