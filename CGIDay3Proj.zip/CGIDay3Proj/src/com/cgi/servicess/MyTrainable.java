package com.cgi.servicess;

public class MyTrainable  implements Trainable{

	@Override
	public void train() {
	System.out.println("trainable...");
	}

	
	
}
