package Demo1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cgi.exceptionhandling.Emp;

public class CollectionsDemo {
	public static void main(String[] args) {
		
		
		Vector <String> vnames =  new Vector<>();
		vnames.add("ashish");
		vnames.add("hemant");
		
		
		
		Emp e1 = new Emp(1,"Joshua",23233.55f);
		Emp e2 = new Emp(2,"Joshua2",23233.55f);
		Emp e3 = new Emp(3,"Joshua3",23233.55f);
		Emp e4 = new Emp(4,"Joshua4",23233.55f);
		
		Map <String,Integer> map1 = new HashMap<>();
		map1.put("Hetal", 34500);
		map1.put("Nidhi", 45000);
		map1.put("Niki", 38000);
		
		Collection coll = map1.values();
		System.out.println(coll);
		
		Set <String> keys = map1.keySet();
		System.out.println(keys);
		
		Set entries=map1.entrySet();
		System.out.println(entries);

		
		List <String> set1 =  new ArrayList<String>();
		set1.add("apples");
		set1.add("mangoes");
		set1.add("bananas");
	    System.out.println(set1); 
		set1.remove(1);
		System.out.println(set1);
		
		
		List<Integer> salaries = 
				Arrays.asList(23000,45000,56560,55656);
		
		for(Integer sal:salaries)
			System.out.println(sal);
		
		
		
		Iterator iter = set1.iterator();
		while(iter.hasNext())
		{
			
			String s =(String)iter.next();
			System.out.println(s);
		}
		
	
		List<Emp> emps = Arrays.asList(e1,e2,e3,e4);
		System.out.println(emps);
	}

}
