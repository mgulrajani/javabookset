package com.cgi.data;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class BookApp {
	
	static BookDaoImpl daoimpl = new BookDaoImpl();
public static void main(String[] args) {
	try
	{
	
	Scanner scanner =  new Scanner(System.in);
	System.out.println("Enter book id");
	int id=scanner.nextInt();
	System.out.println("enter title");
    String title = scanner.next();
   
    System.out.println("enter author");
    String author =  scanner.next();
    System.out.println("enter date of release in the form of yyyy/mm/dd");
    LocalDate ld =  LocalDate.now();
    
    
    
    Book b1 =  
    new Book(id,title,author,ld);
    daoimpl.addBook(b1);
    
    		
   
	}
	catch(SQLException sq)
	{
		sq.printStackTrace();
	}
    
	
	
}
}	
