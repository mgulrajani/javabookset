package com.cgi.data;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class BookDaoImpl  implements BookDao{
	
private static Connection con =  ConnectionManager.getConnection();
private static PreparedStatement statement ;

	
@Override
	public void addBook(Book b) throws SQLException {
		// TODO Auto-generated method stub
	java.sql.Date dor =   Date.valueOf(b.getDateofrelease());
	System.out.println(dor);
	System.out.println("in the method to add book "+b);
		String sql = "insert into book(id,title) "
				+ "values(?,?)";
		statement = con.prepareStatement(sql);
		
		
		statement.setInt(1, b.getBookId());
		statement.setString(2, b.getTitle());
		/*statement.setString(3, b.getAuthor());
		statement.setDate(4, dor);*/
		System.out.println("after setters of statement");
		System.out.println(statement);
		int res = statement.executeUpdate(sql);
		
		System.out.println(res);
		if (res==1)
		{
			System.out.println("book added");
     		}

	String sql2=
	"insert into book values(3,'shiva',null,null)";
statement= con.prepareStatement(sql);
int retval =  statement.executeUpdate();
if (retval==1)
	System.out.println("book added");
			
	}

	@Override
	public void updateBook(Book b) throws SQLException {
		
		String str = "update book set title=?,author=? where id=?";
				
				
				statement = con.prepareStatement(str);
		statement.setString(1, b.getTitle());
		statement.setString(2, b.getAuthor());
		statement.setInt(3, b.getBookId());
		int res = statement.executeUpdate(str);
		if (res==1)
		{
			System.out.println("book updated ...");
		}
				
		
	}

	@Override
	public void deleteBook(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Book getBookById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

}
