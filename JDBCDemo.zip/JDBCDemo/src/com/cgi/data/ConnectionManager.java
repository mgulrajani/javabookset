package com.cgi.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
private static Connection connection = null;

private ConnectionManager() {}

public static Connection getConnection()
{
	
	try
	{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		//2 Step  obtaining the connection object
		
		 connection =DriverManager
		  .getConnection("jdbc:oracle:thin:@localhost :1521:XE","hr","hr");
		  
		
	}
	catch(ClassNotFoundException cnf)
	{
	System.out.println("Driver class not found ..");	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	 return connection; 
	  
}

}
