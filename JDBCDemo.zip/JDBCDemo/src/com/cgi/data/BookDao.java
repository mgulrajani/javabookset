package com.cgi.data;

import java.sql.SQLException;
import java.util.List;

public interface BookDao {

	 public void addBook(Book b) throws SQLException;
	 public void updateBook(Book b) throws SQLException;
	 public void deleteBook(int id);
	 public Book getBookById(int id);
	 public List<Book> getAllBooks();
	 
}
