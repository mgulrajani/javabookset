package com.cgi.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DepartmentsData {

	
	
public static void main(String[] args) {
	
	//1step Registering the driver class
    try
    {
    getData();
    addData();
    
    }
    catch(SQLException sq)
    {
    	sq.printStackTrace();
    	
    }
		
		
	
    
	
}


private static void addData() throws SQLException {
	// TODO Auto-generated method stub
	

	String addQuery = "insert into departments  values(?,?,?,?)";
	
   Connection connection =  ConnectionManager.getConnection();
   
   PreparedStatement ps =  connection.prepareStatement(addQuery);
   Scanner scanner =  new Scanner(System.in);
   System.out.println("Enter department id");
   int id =  scanner.nextInt();
   System.out.println("enter dept name");
   String dname =  scanner.next();
   System.out.println("enter mgr id");
   int mgrid =  scanner.nextInt();
   System.out.println("enter location id ");
   int locationid =  scanner.nextInt();
   
   
   ps.setInt(1, id);
   ps.setString(2, dname);
   ps.setInt(3, mgrid);
   ps.setInt(4, locationid);
	
	int retval = ps.executeUpdate();
	
	if(retval == 1)
		System.out.println("Record added successfully");
   
}


private static void getData() throws SQLException
{
	String query =
			"select * from departments where manager_id is not null";

	
	
	
	   Connection connection =
			ConnectionManager.getConnection();
	  Statement statement =connection.createStatement();
	 ResultSet resultset = statement.executeQuery(query);
	
      System.out.println(connection);


			try(connection;statement;resultset)
				
{
	//4th step executequery
	
	while(resultset.next())
	{
		//String departmentName =  resultset.getString(2);
		
		String deptName =  resultset.getString("department_name");
		
		int mgrId =  resultset.getInt(3);
		
		System.out.println(deptName + " "+mgrId);
		
		
		
		
		
	}
	
}}}

