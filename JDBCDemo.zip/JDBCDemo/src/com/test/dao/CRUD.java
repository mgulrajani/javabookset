
package com.test.dao;
import java.sql.*;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CRUD {

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet rs = null;
        try {
            //1.Registring the driver class with the app
            Class.forName("oracle.jdbc.driver.OracleDriver");
            //2.to get the connection
            connection =DriverManager.getConnection
        ("jdbc:oracle:thin:@localhost:1521:xe", "hr","hr");
            System.out.println(connection);
            //3.to create the sql statement
            String query = 
                    "select first_name,salary from "
                    + "employees where department_id = 30";
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
            while (rs.next())
            {
            String nm=rs.getString(1);
            float sal=rs.getFloat(2);
                System.out.println(nm + "    "+ sal);
            }
            
            
        } catch (ClassNotFoundException ex) {
            System.out.println("driver class not registered .....");
        } catch (SQLException ex) {
            System.out.println("some sql exception...");    
        ex.printStackTrace();
        
    }
    }
}
